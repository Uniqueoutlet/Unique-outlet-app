import 'package:flutter/material.dart';
import 'services/brand_theme.dart';

void main() => runApp(const UniqueOutletApp());

class UniqueOutletApp extends StatelessWidget {
  const UniqueOutletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Unique Outlet',
      debugShowCheckedModeBanner: false,
      theme: UOBrand.theme(),
      home: const UOBrandingPreview(),
    );
  }
}

class UOBrandingPreview extends StatelessWidget {
  const UOBrandingPreview({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset('assets/branding/unique_outlet_logo_tm.png', height: 42),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Image.asset('assets/branding/unique_outlet_splash.png', width: double.infinity),
              const SizedBox(height: 24),
              const Text('Unique Outlet', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              const Text('App branding is ready. Connect this asset set to the existing Phase 10 app.'),
            ],
          ),
        ),
      ),
    );
  }
}
