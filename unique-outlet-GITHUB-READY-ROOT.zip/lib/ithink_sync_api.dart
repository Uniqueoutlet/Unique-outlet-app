import 'dart:convert';
import 'package:http/http.dart' as http;

class IThinkSyncApi {
  final String baseUrl;
  final String adminToken;

  IThinkSyncApi({required this.baseUrl, required this.adminToken});

  Future<Map<String, dynamic>> syncStagingOrder(int orderId) async {
    final r = await http.post(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/ithink/staging/sync-order/$orderId'),
      headers: {
        'Authorization': 'Bearer $adminToken',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('iThink staging sync failed: ${r.statusCode}');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> status(int orderId) async {
    final r = await http.get(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/ithink/staging/sync-status/$orderId'),
      headers: {'Authorization': 'Bearer $adminToken'},
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Unable to load sync status');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
