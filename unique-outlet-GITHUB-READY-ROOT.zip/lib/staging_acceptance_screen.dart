import 'package:flutter/material.dart';
import '../services/staging_acceptance_api.dart';

class StagingAcceptanceScreen extends StatefulWidget {
  final int orderId;
  final StagingAcceptanceApi api;
  const StagingAcceptanceScreen({super.key, required this.orderId, required this.api});

  @override
  State<StagingAcceptanceScreen> createState() => _StagingAcceptanceScreenState();
}

class _StagingAcceptanceScreenState extends State<StagingAcceptanceScreen> {
  Map<String, dynamic>? data;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final d = await widget.api.get(widget.orderId);
      if (mounted) setState(() { data = d; loading = false; });
    } catch (_) {
      if (mounted) setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final checks = Map<String, dynamic>.from(data?['checks'] ?? {});
    final labels = {
      'sync_ok':'Order sync',
      'awb_verified':'AWB verified',
      'label_verified':'Label verified',
      'manifest_verified':'Manifest verified',
      'tracking_verified':'Tracking verified',
      'cancellation_verified':'Cancellation verified',
    };

    return Scaffold(
      appBar: AppBar(title: const Text('Staging Acceptance')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Order #${widget.orderId}', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          ...labels.entries.map((e) => ListTile(
            leading: Icon(
              checks[e.key] == true ? Icons.check_circle : Icons.radio_button_unchecked,
            ),
            title: Text(e.value),
          )),
          const SizedBox(height: 12),
          Text(data?['ready'] == true
              ? 'All staging acceptance checks are complete.'
              : 'Staging acceptance is not complete yet.'),
          const SizedBox(height: 12),
          const Text('Production shipping remains disabled until all checks pass and merchant/provider approval is complete.'),
        ],
      ),
    );
  }
}
