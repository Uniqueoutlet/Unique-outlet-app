import 'package:flutter/material.dart';
import '../services/shipping_operations_api.dart';

class ShipmentTrackingScreen extends StatefulWidget {
  final ShippingOperationsApi api; final int orderId;
  const ShipmentTrackingScreen({super.key, required this.api, required this.orderId});
  @override State<ShipmentTrackingScreen> createState()=>_ShipmentTrackingScreenState();
}
class _ShipmentTrackingScreenState extends State<ShipmentTrackingScreen>{
  late Future<Map<String,dynamic>> future;
  @override void initState(){super.initState();future=widget.api.orderTracking(widget.orderId);}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Track Order')),body:FutureBuilder<Map<String,dynamic>>(future:future,builder:(c,s){if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());if(s.hasError)return Center(child:Text(s.error.toString()));final list=(s.data?['shipments'] as List? ?? []);if(list.isEmpty)return const Center(child:Text('Shipment is being prepared.'));return ListView.separated(padding:const EdgeInsets.all(16),itemCount:list.length,itemBuilder:(c,i){final x=Map<String,dynamic>.from(list[i]);return Card(child:ListTile(title:Text('Shipment ${i+1}'),subtitle:Text('AWB: ${x['awb']?.toString().isEmpty??true?'Pending':x['awb']}\nStatus: ${x['status'] ?? 'Pending'}\nProvider: ${x['provider'] ?? 'iThink'}'),isThreeLine:true,leading:const Icon(Icons.local_shipping_outlined)));},separatorBuilder:(_,__)=>const SizedBox(height:8));}));
}
