import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ShippingProviderApi {
  static const baseUrl = 'https://www.uniqueoutlet.in/wp-json/unique-outlet/v1';

  Future<Map<String, dynamic>> getProvider() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('uo_mobile_token');
    if (token == null || token.isEmpty) throw Exception('Please login first');

    final response = await http.get(
      Uri.parse('$baseUrl/shipping/provider'),
      headers: {'Authorization': 'Bearer $token'},
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Unable to load shipping provider');
    }
    return Map<String, dynamic>.from(data);
  }
}
