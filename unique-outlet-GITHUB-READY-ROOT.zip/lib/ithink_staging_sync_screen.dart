import 'package:flutter/material.dart';
import '../services/ithink_sync_api.dart';

class IThinkStagingSyncScreen extends StatefulWidget {
  final int orderId;
  final IThinkSyncApi api;
  const IThinkStagingSyncScreen({super.key, required this.orderId, required this.api});

  @override
  State<IThinkStagingSyncScreen> createState() => _IThinkStagingSyncScreenState();
}

class _IThinkStagingSyncScreenState extends State<IThinkStagingSyncScreen> {
  bool loading = false;
  String result = 'Ready for controlled staging sync.';

  Future<void> sync() async {
    setState(() { loading = true; });
    try {
      final d = await widget.api.syncStagingOrder(widget.orderId);
      setState(() {
        result = 'Status: ${d['status']}\nAWB: ${d['awb'] ?? 'Not returned'}\nProvider Ref: ${d['provider_ref'] ?? '-'}';
      });
    } catch (e) {
      setState(() { result = 'Sync failed. Check server logs and iThink response.'; });
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('iThink Staging Sync')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('WooCommerce Order #${widget.orderId}', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          const Text('This action is staging-only and uses server-side iThink credentials.'),
          const SizedBox(height: 20),
          Text(result),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: loading ? null : sync,
            child: Text(loading ? 'Syncing…' : 'Sync to iThink Staging'),
          ),
        ],
      ),
    ),
  );
}
