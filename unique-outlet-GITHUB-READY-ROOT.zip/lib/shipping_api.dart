import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ShippingApi {
  static const baseUrl = 'https://www.uniqueoutlet.in/wp-json/unique-outlet/v1';

  Future<Map<String, String>> _headers() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('uo_mobile_token');
    if (token == null || token.isEmpty) throw Exception('Please login first');
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
  }

  Future<Map<String, dynamic>> config() async {
    final response = await http.get(
      Uri.parse('$baseUrl/shipping/config'),
      headers: await _headers(),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Shipping config failed');
    }
    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>> serviceability(String pincode) async {
    final response = await http.post(
      Uri.parse('$baseUrl/shipping/serviceability'),
      headers: await _headers(),
      body: jsonEncode({'pincode': pincode}),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Serviceability check failed');
    }
    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>> rates({
    required String pincode,
    required int vendorId,
    required double weight,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/shipping/rates'),
      headers: await _headers(),
      body: jsonEncode({
        'pincode': pincode,
        'vendor_id': vendorId,
        'weight': weight,
      }),
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Shipping rate failed');
    }
    return Map<String, dynamic>.from(data);
  }
}
