import 'package:flutter/material.dart';
import '../services/vendor_orders_api.dart';

class VendorOrderGroupsScreen extends StatefulWidget {
  final int orderId;
  const VendorOrderGroupsScreen({super.key, required this.orderId});

  @override
  State<VendorOrderGroupsScreen> createState() => _VendorOrderGroupsScreenState();
}

class _VendorOrderGroupsScreenState extends State<VendorOrderGroupsScreen> {
  final api = VendorOrdersApi();
  Map<String, dynamic>? data;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await api.getVendorGroups(widget.orderId);
      if (mounted) setState(() { data = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Vendor Orders')),
        body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(error!, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: load, child: const Text('Retry')),
        ])),
      );
    }

    final vendors = (data?['vendors'] as List?) ?? [];
    return Scaffold(
      appBar: AppBar(title: Text('Order #${data?['order_number'] ?? widget.orderId}')),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: vendors.length,
          itemBuilder: (_, index) {
            final v = Map<String, dynamic>.from(vendors[index]);
            final items = (v['items'] as List?) ?? [];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(v['vendor_name']?.toString() ?? 'Vendor',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  if ((v['warehouse_name'] ?? '').toString().isNotEmpty)
                    Text('Warehouse: ${v['warehouse_name']}'),
                  const SizedBox(height: 8),
                  ...items.map((item) {
                    final m = Map<String, dynamic>.from(item);
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(m['name']?.toString() ?? 'Product'),
                      subtitle: Text('Qty: ${m['quantity'] ?? 1}'),
                      trailing: Text('₹${m['total'] ?? '0'}'),
                    );
                  }),
                  const Divider(),
                  Text('Subtotal: ₹${v['subtotal'] ?? '0'}'),
                  const SizedBox(height: 5),
                  Text('Shipment: ${(v['shipment_status'] ?? 'Not created').toString()}'),
                  if ((v['awb'] ?? '').toString().isNotEmpty)
                    Text('AWB: ${v['awb']}'),
                  if ((v['shipping_provider'] ?? '').toString().isNotEmpty)
                    Text('Provider: ${v['shipping_provider']}'),
                ]),
              ),
            );
          },
        ),
      ),
    );
  }
}
