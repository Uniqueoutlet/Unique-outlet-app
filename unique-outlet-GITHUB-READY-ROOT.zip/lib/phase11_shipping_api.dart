import 'dart:convert';
import 'package:http/http.dart' as http;

class Phase11ShippingApi {
  final String baseUrl;
  Phase11ShippingApi({required this.baseUrl});

  Future<Map<String, dynamic>> track(String awb) async {
    final r = await http.get(Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/track/${Uri.encodeComponent(awb)}'));
    final body = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(body is Map ? (body['message'] ?? 'Tracking failed') : 'Tracking failed');
    }
    return Map<String, dynamic>.from(body as Map);
  }
}
