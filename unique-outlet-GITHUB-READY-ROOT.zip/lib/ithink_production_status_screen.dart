import 'package:flutter/material.dart';
import '../services/ithink_production_api.dart';

class IThinkProductionStatusScreen extends StatefulWidget {
 final IThinkProductionApi api;
 const IThinkProductionStatusScreen({super.key,required this.api});
 @override State<IThinkProductionStatusScreen> createState()=>_IThinkProductionStatusScreenState();
}
class _IThinkProductionStatusScreenState extends State<IThinkProductionStatusScreen>{
 late Future<Map<String,dynamic>> f;
 @override void initState(){super.initState();f=widget.api.config();}
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('iThink Shipping Status')),
  body:FutureBuilder<Map<String,dynamic>>(future:f,builder:(c,s){
   if(!s.hasData)return const Center(child:CircularProgressIndicator());
   final x=s.data!;
   return Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('Adapter: ${x['enabled']==true?'Enabled':'Disabled'}',style:Theme.of(context).textTheme.titleLarge),
    const SizedBox(height:12),
    Text('Mode: ${x['sandbox']==true?'Sandbox':'Production'}'),
    Text('Credentials configured: ${x['configured']==true?'Yes':'No'}'),
    const SizedBox(height:20),
    const Text('Credentials are never sent to the mobile app.'),
   ]));
  }));
}
