import 'dart:convert';
import 'package:http/http.dart' as http;

class ShippingTrackingApi {
  final String baseUrl;
  final String token;
  ShippingTrackingApi({required this.baseUrl, required this.token});

  Future<Map<String, dynamic>> getTracking(int shipmentId) async {
    final r = await http.get(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipments/$shipmentId/tracking'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Tracking request failed: ${r.statusCode}');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
