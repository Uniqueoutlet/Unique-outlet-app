import 'dart:convert';
import 'package:http/http.dart' as http;

class StagingAcceptanceApi {
  final String baseUrl;
  final String token;

  StagingAcceptanceApi({required this.baseUrl, required this.token});

  Future<Map<String, dynamic>> get(int orderId) async {
    final r = await http.get(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/staging/acceptance/$orderId'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Acceptance status failed');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> update(int orderId, Map<String, dynamic> data) async {
    final r = await http.post(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/staging/acceptance/$orderId'),
      headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
      body: jsonEncode(data),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Acceptance update failed');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
