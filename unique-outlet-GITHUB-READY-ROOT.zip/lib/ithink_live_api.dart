import 'dart:convert';
import 'package:http/http.dart' as http;
class IThinkLiveApi {
 final String baseUrl; final String token;
 IThinkLiveApi({required this.baseUrl,required this.token});
 Future<Map<String,dynamic>> config() async {
  final r=await http.get(Uri.parse('$baseUrl/shipping/ithink/live/config')); return jsonDecode(r.body);
 }
 Future<Map<String,dynamic>> track(String awb) async {
  final r=await http.get(Uri.parse('$baseUrl/shipping/ithink/live/track/$awb'),
   headers:{'Authorization':'Bearer $token'}); return jsonDecode(r.body);
 }
}
