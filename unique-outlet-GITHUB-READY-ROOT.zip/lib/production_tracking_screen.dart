import 'package:flutter/material.dart';
import '../services/production_shipping_api.dart';

class ProductionTrackingScreen extends StatefulWidget {
  final int orderId; final ProductionShippingApi api;
  const ProductionTrackingScreen({super.key,required this.orderId,required this.api});
  @override State<ProductionTrackingScreen> createState()=>_ProductionTrackingScreenState();
}
class _ProductionTrackingScreenState extends State<ProductionTrackingScreen>{
 late Future<Map<String,dynamic>> future;
 @override void initState(){super.initState();future=widget.api.tracking(widget.orderId);}
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:Text('Track Order #${widget.orderId}')),
  body:FutureBuilder<Map<String,dynamic>>(future:future,builder:(c,s){
   if(!s.hasData)return const Center(child:CircularProgressIndicator());
   final list=(s.data!['shipments'] as List? ?? const []);
   if(list.isEmpty)return const Center(child:Text('No shipment found.'));
   return ListView.builder(padding:const EdgeInsets.all(16),itemCount:list.length,itemBuilder:(c,i){
    final x=list[i] as Map<String,dynamic>;
    return Card(child:ListTile(title:Text('Shipment ${x['id']}'),
      subtitle:Text('Status: ${x['status']??'—'}\nAWB: ${x['awb']??'Not assigned'}'),isThreeLine:true));
   });
  }));
}
