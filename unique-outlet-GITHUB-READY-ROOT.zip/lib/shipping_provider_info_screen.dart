import 'package:flutter/material.dart';
import '../services/shipping_provider_api.dart';

class ShippingProviderInfoScreen extends StatefulWidget {
  const ShippingProviderInfoScreen({super.key});

  @override
  State<ShippingProviderInfoScreen> createState() => _ShippingProviderInfoScreenState();
}

class _ShippingProviderInfoScreenState extends State<ShippingProviderInfoScreen> {
  final api = ShippingProviderApi();
  Map<String, dynamic>? data;
  String? error;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await api.getProvider();
      if (mounted) setState(() { data = result; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Shipping Provider')),
        body: Center(child: Text(error!)),
      );
    }

    final capabilities = Map<String, dynamic>.from(data?['capabilities'] ?? {});
    final enabled = data?['enabled'] == true;
    final sandbox = data?['sandbox'] == true;

    return Scaffold(
      appBar: AppBar(title: const Text('Shipping Provider')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(
            title: Text(data?['provider']?.toString().toUpperCase() ?? 'GENERIC'),
            subtitle: Text(enabled ? 'Shipping enabled' : 'Shipping disabled'),
            trailing: Icon(enabled ? Icons.check_circle : Icons.pause_circle),
          )),
          Card(child: ListTile(
            title: const Text('Environment'),
            subtitle: Text(sandbox ? 'Sandbox / Test' : 'Production'),
          )),
          const SizedBox(height: 12),
          const Text('Capabilities', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ...capabilities.entries.map((e) => ListTile(
            dense: true,
            leading: Icon(e.value == true ? Icons.check : Icons.close),
            title: Text(e.key.replaceAll('_', ' ').toUpperCase()),
          )),
        ],
      ),
    );
  }
}
