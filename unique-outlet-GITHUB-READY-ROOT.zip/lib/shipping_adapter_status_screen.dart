import 'package:flutter/material.dart';

class ShippingAdapterStatusScreen extends StatelessWidget {
  const ShippingAdapterStatusScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shipping Integration')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: const [
          Card(child: ListTile(
            leading: Icon(Icons.security),
            title: Text('Credentials stay on server'),
            subtitle: Text('The mobile app never receives shipping API secrets.'),
          )),
          Card(child: ListTile(
            leading: Icon(Icons.sync),
            title: Text('Provider-neutral adapter'),
            subtitle: Text('The same app contract can support iThink, Shiprocket, Delhivery or Shipway.'),
          )),
          Card(child: ListTile(
            leading: Icon(Icons.verified),
            title: Text('No fake shipment success'),
            subtitle: Text('AWB and shipment status are shown only after the provider confirms them.'),
          )),
        ],
      ),
    );
  }
}
