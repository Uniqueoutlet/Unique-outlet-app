import 'package:flutter/material.dart';
import 'order_detail_screen.dart';

class OrderConfirmationScreen extends StatelessWidget {
  final int orderId;
  final String orderNumber;
  final String status;

  const OrderConfirmationScreen({
    super.key,
    required this.orderId,
    required this.orderNumber,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    final paid = ['processing', 'completed'].contains(status.toLowerCase());
    return Scaffold(
      appBar: AppBar(title: const Text('Order Confirmed')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(paid ? Icons.check_circle : Icons.receipt_long,
                  size: 86, color: paid ? Colors.green : Colors.orange),
              const SizedBox(height: 20),
              Text(paid ? 'Order placed successfully!' : 'Order created',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text('Order #$orderNumber', style: const TextStyle(fontSize: 17)),
              const SizedBox(height: 8),
              Text('Current status: ${status.toUpperCase()}'),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => OrderDetailScreen(orderId: orderId),
                  )),
                  child: const Text('VIEW ORDER'),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                child: const Text('CONTINUE SHOPPING'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
