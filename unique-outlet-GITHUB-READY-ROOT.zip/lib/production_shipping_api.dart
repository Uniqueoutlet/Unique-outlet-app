import 'dart:convert';
import 'package:http/http.dart' as http;

class ProductionShippingApi {
  final String baseUrl;
  final String token;
  ProductionShippingApi({required this.baseUrl, required this.token});

  Future<Map<String,dynamic>> status() async {
    final r=await http.get(Uri.parse('$baseUrl/shipping/production/status'));
    return jsonDecode(r.body);
  }
  Future<Map<String,dynamic>> createShipment(int orderId) async {
    final r=await http.post(Uri.parse('$baseUrl/shipping/production/create/$orderId'),
      headers:{'Authorization':'Bearer $token','Content-Type':'application/json'});
    return jsonDecode(r.body);
  }
  Future<Map<String,dynamic>> tracking(int orderId) async {
    final r=await http.get(Uri.parse('$baseUrl/shipping/production/tracking/$orderId'),
      headers:{'Authorization':'Bearer $token'});
    return jsonDecode(r.body);
  }
  Future<Map<String,dynamic>> action(int shipmentId,String action) async {
    final r=await http.post(Uri.parse('$baseUrl/shipping/production/action/$shipmentId'),
      headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},
      body:jsonEncode({'action':action}));
    return jsonDecode(r.body);
  }
}
