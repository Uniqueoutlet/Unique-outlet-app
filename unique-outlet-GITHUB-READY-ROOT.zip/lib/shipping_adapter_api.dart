import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ShippingAdapterApi {
  static const baseUrl = 'https://www.uniqueoutlet.in/wp-json/unique-outlet/v1';

  Future<Map<String, String>> headers() async {
    final p = await SharedPreferences.getInstance();
    final token = p.getString('uo_mobile_token');
    if (token == null || token.isEmpty) throw Exception('Please login first');
    return {'Content-Type':'application/json','Authorization':'Bearer $token'};
  }

  Future<Map<String, dynamic>> rate(Map<String, dynamic> payload) async {
    final r = await http.post(
      Uri.parse('$baseUrl/shipping/adapter/rate'),
      headers: await headers(),
      body: jsonEncode(payload),
    );
    final d = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(d['message']?.toString() ?? 'Shipping rate failed');
    }
    return Map<String,dynamic>.from(d);
  }

  Future<Map<String, dynamic>> track(String awb) async {
    final r = await http.get(
      Uri.parse('$baseUrl/shipping/adapter/track/${Uri.encodeComponent(awb)}'),
      headers: await headers(),
    );
    final d = jsonDecode(r.body);
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception(d['message']?.toString() ?? 'Tracking failed');
    }
    return Map<String,dynamic>.from(d);
  }
}
