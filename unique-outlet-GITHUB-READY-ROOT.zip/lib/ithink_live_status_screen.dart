import 'package:flutter/material.dart';
import '../services/ithink_live_api.dart';
class IThinkLiveStatusScreen extends StatefulWidget{
 final IThinkLiveApi api; const IThinkLiveStatusScreen({super.key,required this.api});
 @override State<IThinkLiveStatusScreen> createState()=>_IThinkLiveStatusScreenState();
}
class _IThinkLiveStatusScreenState extends State<IThinkLiveStatusScreen>{
 late Future<Map<String,dynamic>> f;
 @override void initState(){super.initState();f=widget.api.config();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('iThink Live Status')),
 body:FutureBuilder<Map<String,dynamic>>(future:f,builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  final x=s.data!;return Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Text('Adapter: ${x['enabled']==true?'Enabled':'Disabled'}'),
   Text('Live creation: ${x['allow_live_create']==true?'Unlocked':'Locked'}'),
   Text('Credentials: ${x['configured']==true?'Configured':'Missing'}'),
  ]));
 }));
}
