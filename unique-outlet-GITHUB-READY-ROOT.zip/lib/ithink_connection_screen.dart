import 'package:flutter/material.dart';
import '../services/ithink_staging_api.dart';

class IThinkConnectionScreen extends StatefulWidget {
  final IThinkStagingApi api;
  const IThinkConnectionScreen({super.key, required this.api});

  @override
  State<IThinkConnectionScreen> createState() => _IThinkConnectionScreenState();
}

class _IThinkConnectionScreenState extends State<IThinkConnectionScreen> {
  bool loading = false;
  String message = 'Not checked';

  Future<void> check() async {
    setState(() { loading = true; });
    try {
      final d = await widget.api.readiness();
      setState(() {
        message = d['ready'] == true
            ? 'iThink configuration is ready for a controlled staging API test.'
            : 'iThink credentials/settings are not complete.';
      });
    } catch (_) {
      setState(() { message = 'Unable to check iThink configuration.'; });
    } finally {
      setState(() { loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('iThink Logistics')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Staging connection', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Text(message),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: loading ? null : check,
            child: Text(loading ? 'Checking…' : 'Check configuration'),
          ),
          const SizedBox(height: 16),
          const Text('Shipping credentials remain on the WordPress server and are never bundled in the mobile app.')
        ],
      ),
    ),
  );
}
