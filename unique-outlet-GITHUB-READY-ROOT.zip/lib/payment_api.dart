import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class PaymentApi {
  static const baseUrl = 'https://www.uniqueoutlet.in/wp-json/unique-outlet/v1';

  Future<Map<String, dynamic>> createOrder({
    required List<Map<String, dynamic>> items,
    required Map<String, dynamic> billing,
    required Map<String, dynamic> shipping,
    required String paymentMethod,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('uo_mobile_token');
    if (token == null || token.isEmpty) {
      throw Exception('Please login first');
    }

    final response = await http.post(
      Uri.parse('$baseUrl/orders'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'items': items,
        'billing': billing,
        'shipping': shipping,
        'payment_method': paymentMethod,
      }),
    );

    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Order creation failed');
    }
    return Map<String, dynamic>.from(data);
  }

  Future<Map<String, dynamic>> getOrder(int orderId) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('uo_mobile_token');
    if (token == null || token.isEmpty) throw Exception('Please login first');

    final response = await http.get(
      Uri.parse('$baseUrl/orders/$orderId'),
      headers: {'Authorization': 'Bearer $token'},
    );
    final data = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Unable to load order');
    }
    return Map<String, dynamic>.from(data);
  }
}
