import 'dart:convert';
import 'package:http/http.dart' as http;

class IThinkProductionApi {
  final String baseUrl;
  final String token;
  IThinkProductionApi({required this.baseUrl,required this.token});

  Future<Map<String,dynamic>> config() async {
    final r=await http.get(Uri.parse('$baseUrl/shipping/ithink/production/config'));
    return jsonDecode(r.body);
  }

  Future<Map<String,dynamic>> test() async {
    final r=await http.post(Uri.parse('$baseUrl/shipping/ithink/production/test'),
      headers:{'Authorization':'Bearer $token','Content-Type':'application/json'});
    return jsonDecode(r.body);
  }
}
