import 'dart:convert';
import 'package:http/http.dart' as http;

class ShippingOperationsApi {
  final String baseUrl;
  final String? bearerToken;
  ShippingOperationsApi({required this.baseUrl, this.bearerToken});

  Map<String,String> get _headers => {
    'Content-Type':'application/json',
    if (bearerToken != null && bearerToken!.isNotEmpty) 'Authorization':'Bearer $bearerToken!',
  };

  Future<Map<String,dynamic>> pincodeCheck(String pincode) async {
    final r=await http.post(Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/v2/pincode-check'),headers:_headers,body:jsonEncode({'pincode':pincode}));
    return _decode(r);
  }
  Future<Map<String,dynamic>> rate({required String fromPincode,required double length,required double width,required double height,required double weight,required String paymentMethod,required double productMrp}) async {
    final r=await http.post(Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/v2/rate'),headers:_headers,body:jsonEncode({'from_pincode':fromPincode,'shipping_length_cms':length,'shipping_width_cms':width,'shipping_height_cms':height,'shipping_weight_kg':weight,'payment_method':paymentMethod,'product_mrp':productMrp}));
    return _decode(r);
  }
  Future<Map<String,dynamic>> track(String awb) async { final r=await http.get(Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/v2/track/$awb'),headers:_headers); return _decode(r); }
  Future<Map<String,dynamic>> orderTracking(int orderId) async { final r=await http.get(Uri.parse('$baseUrl/wp-json/unique-outlet/v1/orders/$orderId/tracking'),headers:_headers); return _decode(r); }
  Map<String,dynamic> _decode(http.Response r){ final d=jsonDecode(r.body); if(r.statusCode<200||r.statusCode>=300) throw Exception(d is Map&&d['message']!=null?d['message']:'Shipping request failed'); return Map<String,dynamic>.from(d as Map); }
}
