import 'dart:convert';
import 'package:http/http.dart' as http;

class IThinkStagingApi {
  final String baseUrl;
  final String adminToken;
  IThinkStagingApi({required this.baseUrl, required this.adminToken});

  Future<Map<String, dynamic>> readiness() async {
    final r = await http.post(
      Uri.parse('$baseUrl/wp-json/unique-outlet/v1/shipping/ithink/staging/test'),
      headers: {'Authorization': 'Bearer $adminToken', 'Content-Type': 'application/json'},
      body: jsonEncode({}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('iThink readiness check failed');
    }
    return jsonDecode(r.body) as Map<String, dynamic>;
  }
}
