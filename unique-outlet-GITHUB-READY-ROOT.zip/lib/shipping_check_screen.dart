import 'package:flutter/material.dart';
import '../services/shipping_api.dart';

class ShippingCheckScreen extends StatefulWidget {
  final int? vendorId;
  const ShippingCheckScreen({super.key, this.vendorId});

  @override
  State<ShippingCheckScreen> createState() => _ShippingCheckScreenState();
}

class _ShippingCheckScreenState extends State<ShippingCheckScreen> {
  final api = ShippingApi();
  final pincode = TextEditingController();
  bool loading = false;
  String? message;

  Future<void> check() async {
    final pin = pincode.text.trim();
    if (pin.length != 6) {
      setState(() => message = 'Please enter a valid 6 digit pincode.');
      return;
    }
    setState(() { loading = true; message = null; });
    try {
      final result = await api.serviceability(pin);
      final status = result['status']?.toString() ?? '';
      setState(() {
        message = status == 'provider_check_required'
            ? 'Shipping provider check is not configured yet.'
            : 'Serviceability: ${result['serviceable']}';
        loading = false;
      });
    } catch (e) {
      setState(() { message = e.toString(); loading = false; });
    }
  }

  @override
  void dispose() {
    pincode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Delivery Check')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Check delivery availability',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(
            controller: pincode,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: const InputDecoration(
              labelText: 'PIN code',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: loading ? null : check,
              child: Text(loading ? 'CHECKING...' : 'CHECK DELIVERY'),
            ),
          ),
          if (message != null) ...[
            const SizedBox(height: 18),
            Card(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(message!),
            )),
          ],
        ]),
      ),
    );
  }
}
