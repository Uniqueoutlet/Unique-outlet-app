# Unique Outlet Phase 6 – Payment & Order Confirmation

This phase adds a production-oriented foundation for:
- server-generated invoice number
- order confirmation UI
- authenticated order detail
- WooCommerce payment status as the source of truth
- generic gateway architecture (no Razorpay/PhonePe/Paytm hard-code)

## Important
This is NOT a fake payment implementation. The app must never mark an order paid.
The selected WooCommerce payment gateway/plugin must complete its own verification,
callback/webhook, and WooCommerce status update.

## Install
1. Upload/activate `wordpress-plugin/unique-outlet-phase6-payment-order-confirmation.php`.
2. Keep WooCommerce payment gateway plugins configured in WordPress.
3. Merge the Flutter files into the Phase 5 project.
4. Add routes from the existing checkout flow to `OrderConfirmationScreen`.

## Next production layer
- Gateway-specific initiation adapter/redirect handling.
- Webhook signature verification.
- Payment failure/retry.
- Idempotency keys.
- Server-side stock/variation validation.
- Coupon/tax/shipping calculation.
- Dokan vendor suborders.
- Generic shipping provider adapter.
